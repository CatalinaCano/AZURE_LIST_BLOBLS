﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TestAzureBlob
{
    class Program
    {


        static void Main(string[] args)
        {
            GetBlobs();
        }

        public static async Task<List<IListBlobItem>> ListBlobsAsync(CloudBlobContainer container, string subFolder)
        {
            var continuationToken = new BlobContinuationToken();
            List<IListBlobItem> results = new List<IListBlobItem>();
            do
            {
                var response = await container.ListBlobsSegmentedAsync(subFolder, true, BlobListingDetails.All, null, continuationToken, null, null);
                continuationToken = response.ContinuationToken;
                results.AddRange(response.Results);
            }
            while (continuationToken != null);
            return results;
        }

        public static void GetBlobs()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=computecdatacourrier;AccountKey=IPDhLFxGbEhEIEN5z9ly49QMgCGeD+ynlbP6gUAc1INpe1gFf/U45zg8dOcjbBEjiM2wi781UKn96O1PPI5SXA==;EndpointSuffix=core.windows.net");
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("demo");
            string sub_folder = "entradas";

            if (container.ExistsAsync().Result)
            {
                var blobs = ListBlobsAsync(container, sub_folder);
                var blobNames = new List<string>();
                using System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\catal\Downloads\test_3.txt", true);
                foreach (var item in blobs.Result)
                {
                    var blob = (CloudBlob)item;
                    var name = blob.Name;
                    file.WriteLine(name);
                }
            }

        }
    }
}
