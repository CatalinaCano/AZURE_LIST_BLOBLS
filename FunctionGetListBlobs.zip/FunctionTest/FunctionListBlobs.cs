using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage;
using System.Text;

namespace FunctionTest
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            string containerName = req.Query["containerName"];
            string subContainerName = req.Query["subContainerName"];
            var blobs = GetBlobs(containerName, subContainerName);
            return new OkObjectResult(blobs);
        }

        public static async Task<List<IListBlobItem>> ListBlobsAsync(CloudBlobContainer container, string subFolder)
        {
            var continuationToken = new BlobContinuationToken();
            List<IListBlobItem> results = new List<IListBlobItem>();
            do
            {
                var response = await container.ListBlobsSegmentedAsync(subFolder, true, BlobListingDetails.All, null, continuationToken, null, null);
                continuationToken = response.ContinuationToken;
                results.AddRange(response.Results);
            }
            while (continuationToken != null);
            return results;
        }

        public static String GetBlobs(string containerName, string sub_folder )
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=computecdatacourrier;AccountKey=IPDhLFxGbEhEIEN5z9ly49QMgCGeD+ynlbP6gUAc1INpe1gFf/U45zg8dOcjbBEjiM2wi781UKn96O1PPI5SXA==;EndpointSuffix=core.windows.net");
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            var sb = new StringBuilder();

            if (container.ExistsAsync().Result)
            {
                var blobs = ListBlobsAsync(container, sub_folder);
                var blobNames = new List<string>();
                
                foreach (var item in blobs.Result)
                {
                    var blob = (CloudBlob)item;
                    var name = blob.Name;
                    sb.AppendLine(name);
                }
            }

            return sb.ToString();

        }
    }
}
